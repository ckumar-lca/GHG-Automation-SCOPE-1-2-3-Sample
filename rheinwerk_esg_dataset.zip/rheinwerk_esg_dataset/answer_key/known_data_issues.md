# Planted data issues (spoilers)

Your pipeline should detect and handle each of these, and log how. In interviews these are your "problem-solving" stories.

## Electricity
- CZ01 reported in **MWh**, DE01/IN01 in kWh
- DE01 **Jul–Aug 2024 missing**: estimate from production × intensity, flag as estimated
- One **duplicate row** (same site, same month, uploaded twice)
- DE01 **Nov 2023 is 10× too high** (extra-zero typo): needs an outlier rule (z-score or comparison with kWh/t)
- IN01 has **onsite PV from Apr 2024**: zero Scope 2 emissions, but it must still count in total energy consumption (ESRS E1-5)
- DE01 drops ~7% from 2025 (real efficiency project): a genuine trend, not a data error

## Gas / LPG
- DE01 in **kWh Hs (gross CV)**, while the illustrative EF is per kWh Hi (net): convert (Hi ≈ Hs / 1.11)
- CZ01 in **m³** with date format **MM/YYYY**
- IN01 LPG only **quarterly**: distribute to months if you need monthly granularity
- Gas correlates with heating degree days: regress on HDD + output to get a weather-normalised KPI (2024 was a mild winter)

## Fuel cards
- `;` separator, **decimal comma**, date DD.MM.YYYY, UTF-8 BOM
- **25 duplicate transactions**
- "Strom (kWh)" = EV charging: **not Scope 1**, it's Scope 2 (or exclude if already in a site meter)
- One vehicle has a **Czech plate**: decide on the organisational boundary

## Refrigerants
- "approx 2" as text, a mix of **g and kg**, both "R22" and "R-22"
- **R22 is an ozone-depleting HCFC (Montreal Protocol)**: reported separately and still in use in IN01 → compliance flag

## Guarantees of origin
- DE01 2024 volume of **4,000,000 "MWh?"**: unit error (kWh), so 4,000 MWh
- CZ01 GOs **purchased but not cancelled**: can't be claimed in market-based Scope 2
- Check GO volume ≤ actual consumption per site and year

## SAP purchase orders
- 4 currencies (EUR, INR, CZK, USD): use yearly average FX rates and document the source
- Unit variants **t / TO / to / KG**
- 12 POs with **empty vendor name**: fill from LIFNR
- **MATKL empty**: classify into Scope 3 categories (steel/alu/chemicals → Cat 1, Bosch Rexroth hydraulic unit → **Cat 2 capital goods**, DHL/Maersk → **Cat 4**, Lufthansa → **Cat 6**, office → Cat 1 minor)
- Steel and aluminium POs have a mass, so you can use mass-based instead of spend-based factors: compare both
- Hebei (CN) steel: also relevant for CBAM

## Supplier PCFs
- Mixed units (kgCO2e/kg vs kgCO2e/t), decimal comma "1,9"
- Hindalco: **company average**, not product-specific → lower data-quality score
- Alcomet: **unclear boundary (gate-to-gate?)**, can't be used as cradle-to-gate without clarification
- Different reference years

## BOM (Project 2)
- Units ST / KG / G, one **missing quantity** (adhesive)
- Net weight only on some components: check mass balance (input material vs net weight → scrap rate)
- Material text in German and English, so you need fuzzy matching to LCA datasets

## CBAM (Project 2)
- Chinese supplier **has no actual data**: default values apply, so calculate the cost penalty
- Tata reports **direct emissions only**: indirect emissions are missing
- Show the cost difference: default vs actual × CBAM certificate price

"""
Synthetic, deliberately messy ESG/GHG dataset for "Rheinwerk Komponenten GmbH"
(fictional auto-parts supplier, 3 plants: Duisburg DE, Plzen CZ, Pune IN), 2023-2025.
Data issues are intentional - see answer_key/known_data_issues.md.
"""
import os, random
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
random.seed(42)
OUT = "rheinwerk_esg_dataset"
RAW = f"{OUT}/raw"
REF = f"{OUT}/reference"
KEY = f"{OUT}/answer_key"
for d in (RAW, REF, KEY):
    os.makedirs(d, exist_ok=True)

months = pd.period_range("2023-01", "2025-12", freq="M")

# ---------------- sites ----------------
sites = pd.DataFrame([
    ["DE01", "Werk Duisburg", "DE", "Duisburg", 21000, "machining, heat treatment, assembly"],
    ["CZ01", "Zavod Plzen", "CZ", "Plzen", 14500, "aluminium die casting, machining"],
    ["IN01", "Pune Plant", "IN", "Pune", 18000, "stamping, welding, painting"],
], columns=["site_id", "site_name", "country", "city", "floor_area_m2", "processes"])
sites.to_csv(f"{RAW}/sites.csv", index=False)

# ---------------- heating degree days (synthetic, replace with DWD) ----------------
hdd_profile = {1: 520, 2: 450, 3: 380, 4: 250, 5: 120, 6: 30, 7: 5, 8: 10, 9: 90, 10: 230, 11: 380, 12: 480}
hdd_rows = []
for p in months:
    base = hdd_profile[p.month]
    yr_factor = {2023: 1.0, 2024: 0.88, 2025: 0.95}[p.year]   # 2024 mild winter
    hdd_rows.append(["DE01", str(p), round(base * yr_factor * rng.uniform(0.9, 1.1))])
    hdd_rows.append(["CZ01", str(p), round(base * 1.12 * yr_factor * rng.uniform(0.9, 1.1))])
hdd = pd.DataFrame(hdd_rows, columns=["site_id", "month", "heating_degree_days"])
hdd.to_csv(f"{REF}/heating_degree_days_SYNTHETIC.csv", index=False)
hdd_map = {(r.site_id, r.month): r.heating_degree_days for r in hdd.itertuples()}

# ---------------- production & revenue ----------------
prod_rows = []
base_prod = {"DE01": 410, "CZ01": 520, "IN01": 380}  # tonnes/month
for p in months:
    for s, b in base_prod.items():
        growth = 1 + 0.03 * (p.year - 2023)
        season = 0.75 if p.month in (8, 12) and s != "IN01" else 1.0
        t = b * growth * season * rng.uniform(0.92, 1.08)
        prod_rows.append([s, str(p), round(t, 1), round(t * rng.uniform(5200, 5800), -2)])
prod = pd.DataFrame(prod_rows, columns=["site_id", "month", "output_tonnes", "revenue_eur"])
prod.to_csv(f"{RAW}/production_and_revenue.csv", index=False)
prod_map = {(r.site_id, r.month): r.output_tonnes for r in prod.itertuples()}

# ---------------- electricity (mixed units, gaps, a meter swap) ----------------
elec = []
kwh_per_t = {"DE01": 1900, "CZ01": 2600, "IN01": 1500}
for p in months:
    m = str(p)
    for s in ("DE01", "CZ01", "IN01"):
        kwh = prod_map[(s, m)] * kwh_per_t[s] * rng.uniform(0.95, 1.05)
        if s == "DE01" and m in ("2024-07", "2024-08"):
            continue  # GAP: meter data missing
        if s == "DE01" and m >= "2025-01":
            kwh *= 0.93  # efficiency project (compressed air leaks fixed)
        if s == "CZ01":
            elec.append([s, m, round(kwh / 1000, 3), "MWh", "CEZ Prodej", "grid"])
        elif s == "IN01":
            elec.append([s, m, round(kwh), "kWh", "MSEDCL", "grid"])
            if m >= "2024-04":  # rooftop PV, self-consumed
                elec.append([s, m, round(rng.uniform(55000, 85000)), "kWh", "own rooftop PV", "onsite_pv"])
        else:
            elec.append([s, m, round(kwh), "kWh", "Stadtwerke Duisburg", "grid"])
# duplicate upload
elec.append(elec[10])
# typo outlier (extra zero)
elec.append(["DE01", "2023-11", round(prod_map[("DE01", "2023-11")] * 1900 * 10), "kWh", "Stadtwerke Duisburg", "grid"])
elec = pd.DataFrame(elec, columns=["site_id", "billing_month", "consumption", "unit", "supplier", "source_type"])
# remove the original DE01 2023-11 so the outlier replaces it
mask = (elec.site_id == "DE01") & (elec.billing_month == "2023-11")
idx = elec[mask].index
elec = elec.drop(idx[0])
elec.sample(frac=1, random_state=1).to_csv(f"{RAW}/electricity_invoices.csv", index=False)

# ---------------- natural gas / LPG ----------------
gas = []
for p in months:
    m = str(p)
    # DE: kWh Hs (gross), process + space heating
    de = prod_map[("DE01", m)] * 900 + hdd_map[("DE01", m)] * 520
    gas.append(["DE01", m, round(de * rng.uniform(0.95, 1.05)), "kWh_Hs", "natural gas", "invoice"])
    # CZ: m3
    cz_kwh = prod_map[("CZ01", m)] * 1400 + hdd_map[("CZ01", m)] * 380
    gas.append(["CZ01", m, round(cz_kwh / 10.55 * rng.uniform(0.95, 1.05)), "m3", "natural gas", "invoice"])
    # IN: LPG in kg for paint shop ovens, quarterly invoices only
    if p.month in (3, 6, 9, 12):
        gas.append(["IN01", m, round(prod_map[("IN01", m)] * 3 * 14 * rng.uniform(0.9, 1.1)), "kg", "LPG", "quarterly invoice"])
gas = pd.DataFrame(gas, columns=["site_id", "period", "quantity", "unit", "fuel", "document_type"])
# date format inconsistency for CZ
gas.loc[gas.site_id == "CZ01", "period"] = gas.loc[gas.site_id == "CZ01", "period"].apply(
    lambda x: f"{x[5:7]}/{x[0:4]}")
gas.to_csv(f"{RAW}/gas_and_lpg_invoices.csv", index=False)

# ---------------- fleet fuel cards (German formatting, duplicates) ----------------
fuel = []
plates = ["DU-RK 101", "DU-RK 102", "DU-RK 205", "DU-RK 310", "PZ-4A1 2231"]
for d in pd.date_range("2023-01-01", "2025-12-31", freq="D"):
    for _ in range(rng.poisson(1.6)):
        pl = random.choice(plates)
        ftype = "Diesel" if pl != "DU-RK 310" else random.choice(["Super E10", "Super E10", "Strom (kWh)"])
        litres = rng.uniform(35, 75) if "Strom" not in ftype else rng.uniform(20, 60)
        price = {"Diesel": 1.72, "Super E10": 1.79, "Strom (kWh)": 0.49}[ftype] * rng.uniform(0.92, 1.1)
        fuel.append([d.strftime("%d.%m.%Y"), pl, ftype,
                     f"{litres:.2f}".replace(".", ","), f"{litres * price:.2f}".replace(".", ","),
                     random.choice(["Aral", "Shell", "Esso", "TotalEnergies", "EnBW Laden"])])
fuel = pd.DataFrame(fuel, columns=["Datum", "Kennzeichen", "Kraftstoff", "Menge", "Betrag_EUR", "Station"])
dups = fuel.sample(25, random_state=3)
fuel = pd.concat([fuel, dups]).sort_values("Datum", kind="stable")
fuel.to_csv(f"{RAW}/fuel_card_export_DE.csv", index=False, sep=";", encoding="utf-8-sig")

# ---------------- refrigerants (F-gas log) ----------------
ref = pd.DataFrame([
    ["DE01", "2023-03-14", "Chiller hall 2", "R410A", 4.2, "kg", "leak repair top-up"],
    ["DE01", "2024-06-02", "Server room AC", "R32", 1.1, "kg", "service"],
    ["CZ01", "2023-09-21", "Die-casting cooling", "R134a", 12.5, "kg", "compressor failure"],
    ["CZ01", "2025-02-10", "Office AC", "R410A", "approx 2", "kg", "top-up"],
    ["IN01", "2024-11-05", "Paint booth HVAC", "R22", 6.0, "kg", "top-up"],
    ["IN01", "2025-05-19", "Paint booth HVAC", "R-22", 5800, "g", "top-up"],
], columns=["site_id", "date", "equipment", "refrigerant", "amount_added", "unit", "reason"])
ref.to_csv(f"{RAW}/refrigerant_log.csv", index=False)

# ---------------- guarantees of origin ----------------
go = pd.DataFrame([
    ["DE01", 2024, 4_000_000, "MWh?", "Norwegian hydro", "HKN-NO-2024-88213", "cancelled"],
    ["DE01", 2025, 6500, "MWh", "Norwegian hydro", "HKN-NO-2025-10442", "cancelled"],
    ["CZ01", 2025, 3000, "MWh", "Czech wind", "GO-CZ-2025-551", "purchased_not_cancelled"],
], columns=["site_id", "year", "volume", "unit", "technology", "certificate_id", "status"])
go.to_csv(f"{RAW}/guarantees_of_origin.csv", index=False)

# ---------------- SAP purchase orders (scope 3 cat 1/2/4) ----------------
vendors = [
    ("V1001", "ThyssenKrupp Steel Europe", "DE", "Stahlband DC04 1,5mm", "EUR"),
    ("V1002", "Salzgitter Flachstahl", "DE", "Coil S355 warmgewalzt", "EUR"),
    ("V2001", "Hindalco Industries", "IN", "Aluminium ingot A380", "INR"),
    ("V2002", "Tata Steel", "IN", "HR coil IS2062", "INR"),
    ("V3001", "Alcomet Recycling", "CZ", "Al sekundar slitina AlSi9Cu3", "CZK"),
    ("V4001", "Henkel AG", "DE", "Klebstoff Loctite", "EUR"),
    ("V4002", "Axalta Coating Systems", "IN", "Paint primer grey", "INR"),
    ("V5001", "DHL Freight", "DE", "Fracht Inbound LKW", "EUR"),
    ("V5002", "Maersk", "DK", "Sea freight Nhava Sheva-Hamburg", "USD"),
    ("V6001", "Würth", "DE", "Schrauben M8 Sortiment", "EUR"),
    ("V6002", "Bosch Rexroth", "DE", "Hydraulikaggregat (Anlage)", "EUR"),
    ("V7001", "Staples Office", "DE", "Büromaterial", "EUR"),
    ("V8001", "Lufthansa", "DE", "Flug FRA-PNQ", "EUR"),
    ("V9001", "Hebei Iron & Steel Export", "CN", "Cold rolled coil SPCC", "USD"),
]
fx = {"EUR": 1, "INR": 90, "CZK": 25, "USD": 1.08}
po = []
po_id = 4500010000
for p in months:
    for v in vendors:
        if rng.random() < 0.15 and v[0] not in ("V1001", "V2001", "V3001"):
            continue
        base_eur = {"V1001": 380000, "V1002": 210000, "V2001": 260000, "V2002": 150000, "V3001": 300000,
                    "V4001": 18000, "V4002": 22000, "V5001": 35000, "V5002": 28000, "V6001": 9000,
                    "V6002": 0, "V7001": 1500, "V8001": 6000, "V9001": 120000}[v[0]]
        if v[0] == "V6002":
            if str(p) not in ("2024-03", "2025-09"):
                continue
            base_eur = 480000
        amt_eur = base_eur * rng.uniform(0.8, 1.2)
        qty = ""
        uom = ""
        if v[0] in ("V1001", "V1002", "V2002", "V9001"):
            qty, uom = round(amt_eur / rng.uniform(780, 900), 1), random.choice(["t", "TO", "to"])
        if v[0] in ("V2001", "V3001"):
            qty, uom = round(amt_eur / rng.uniform(2300, 2700) * 1000), "KG"
        po_id += 1
        plant = {"DE": "DE01", "CZ": "CZ01", "IN": "IN01", "DK": "IN01", "CN": "DE01"}[v[2]]
        po.append([po_id, f"{p.year}{p.month:02d}{random.randint(1, 28):02d}", plant, v[0], v[1], v[3],
                   qty, uom, round(amt_eur * fx[v[4]], 2), v[4], "", ""])
po = pd.DataFrame(po, columns=["EBELN", "BEDAT", "WERKS", "LIFNR", "NAME1", "TXZ01",
                               "MENGE", "MEINS", "NETWR", "WAERS", "MATKL", "KOSTL"])
# missing vendor names
po.loc[po.sample(12, random_state=5).index, "NAME1"] = ""
po.to_csv(f"{RAW}/sap_purchase_orders_EKPO.csv", index=False)

# ---------------- supplier PCF responses ----------------
pcf = pd.DataFrame([
    ["V1001", "Stahlband DC04", 2.05, "kgCO2e/kg", "cradle-to-gate", "ISO 14067, third-party verified", 2024],
    ["V1002", "Coil S355", "1,9", "kgCO2e/kg", "cradle-to-gate", "self-declared", 2023],
    ["V2001", "Aluminium ingot A380", 16800, "kgCO2e/t", "cradle-to-gate", "company average, not product-specific", 2023],
    ["V3001", "AlSi9Cu3 secondary", 0.62, "kgCO2e/kg", "gate-to-gate?", "unclear system boundary", 2024],
    ["V4001", "Loctite adhesive", 4.1, "kgCO2e/kg", "cradle-to-gate", "PACT-conformant", 2025],
], columns=["vendor_id", "product", "pcf_value", "unit", "boundary", "verification", "reference_year"])
pcf.to_csv(f"{RAW}/supplier_pcf_responses.csv", index=False)

# ---------------- Project 2: BOM export ----------------
bom = pd.DataFrame([
    ["RK-BRK-4410", "Bremsträger vorne", 0, "RK-BRK-4410", "Bremsträger vorne", 1, "ST", ""],
    ["RK-BRK-4410", "Bremsträger vorne", 1, "RK-HSG-100", "Gehäuse Alu-Druckguss", 1, "ST", 1.85],
    ["RK-BRK-4410", "Bremsträger vorne", 2, "AL-A380", "Aluminium A380", 2.15, "KG", ""],
    ["RK-BRK-4410", "Bremsträger vorne", 1, "RK-BRK-PLT", "Halteblech", 2, "ST", 0.42],
    ["RK-BRK-4410", "Bremsträger vorne", 2, "ST-DC04", "Stahlband DC04 1,5mm", 0.95, "KG", ""],
    ["RK-BRK-4410", "Bremsträger vorne", 1, "SCR-M8", "Schraube M8x25 8.8", 4, "ST", ""],
    ["RK-BRK-4410", "Bremsträger vorne", 1, "PNT-GRY", "primer grey", 0.06, "KG", ""],
    ["RK-SUB-2200", "Querlenker-Halter", 0, "RK-SUB-2200", "Querlenker-Halter", 1, "ST", ""],
    ["RK-SUB-2200", "Querlenker-Halter", 1, "ST-S355", "Coil S355 warmgewalzt", 3.4, "KG", ""],
    ["RK-SUB-2200", "Querlenker-Halter", 1, "SCR-M8", "Schraube M8x25", 2, "ST", ""],
    ["RK-SUB-2200", "Querlenker-Halter", 1, "ADH-LOC", "Klebstoff", "", "G", ""],
], columns=["finished_good", "fg_description", "bom_level", "component", "component_text",
            "quantity", "uom", "net_weight_kg"])
bom.to_csv(f"{RAW}/sap_bom_export_CS12.csv", index=False)

# ---------------- Project 2: CBAM imports ----------------
cbam = pd.DataFrame([
    ["2026-Q1", "72091690", "Cold rolled coil SPCC", "CN", "Hebei Iron & Steel Export", 410.5, "t", "", "", "no data received"],
    ["2026-Q1", "76011000", "Aluminium ingot", "IN", "Hindalco Industries", 290.0, "t", 14.9, "tCO2e/t", "installation-level, direct+indirect"],
    ["2026-Q1", "72083900", "HR coil IS2062", "IN", "Tata Steel", 165.2, "t", 2.3, "tCO2e/t", "direct only"],
    ["2026-Q2", "72091690", "Cold rolled coil SPCC", "CN", "Hebei Iron & Steel Export", 388.0, "t", "", "", "supplier promised Q3"],
    ["2026-Q2", "76011000", "Aluminium ingot", "IN", "Hindalco Industries", 310.4, "t", 14.9, "tCO2e/t", "installation-level, direct+indirect"],
    ["2026-Q2", "72083900", "HR coil IS2062", "IN", "Tata Steel", 172.8, "t", 2.25, "tCO2e/t", "direct only"],
], columns=["quarter", "cn_code", "goods", "origin", "supplier", "quantity", "unit",
            "embedded_emissions", "ee_unit", "supplier_comment"])
cbam.to_csv(f"{RAW}/cbam_imports_2026.csv", index=False)

# ---------------- ILLUSTRATIVE emission factors ----------------
ef = pd.DataFrame([
    ["natural_gas", "kWh_Hi", 0.202, "kgCO2e", "Scope 1", "REPLACE with UBA / DEFRA (net vs gross CV!)"],
    ["diesel", "litre", 2.66, "kgCO2e", "Scope 1", "REPLACE with DEFRA"],
    ["petrol_E10", "litre", 2.10, "kgCO2e", "Scope 1", "REPLACE with DEFRA"],
    ["LPG", "kg", 2.94, "kgCO2e", "Scope 1", "REPLACE with DEFRA"],
    ["grid_DE", "kWh", 0.38, "kgCO2e", "Scope 2 LB", "REPLACE with UBA Strommix"],
    ["grid_CZ", "kWh", 0.43, "kgCO2e", "Scope 2 LB", "REPLACE with EEA / national"],
    ["grid_IN", "kWh", 0.71, "kgCO2e", "Scope 2 LB", "REPLACE with India CEA CO2 baseline"],
    ["residual_mix_DE", "kWh", 0.60, "kgCO2e", "Scope 2 MB", "REPLACE with AIB European Residual Mix"],
    ["residual_mix_CZ", "kWh", 0.65, "kgCO2e", "Scope 2 MB", "REPLACE with AIB European Residual Mix"],
], columns=["activity", "unit", "factor", "factor_unit", "scope", "note"])
ef.to_csv(f"{REF}/emission_factors_ILLUSTRATIVE.csv", index=False)

gwp = pd.DataFrame([["R410A", 2088], ["R32", 675], ["R134a", 1430], ["R22", 1810]],
                   columns=["refrigerant", "gwp100_ILLUSTRATIVE_AR4"])
gwp.to_csv(f"{REF}/refrigerant_gwp_ILLUSTRATIVE.csv", index=False)
print("done")
